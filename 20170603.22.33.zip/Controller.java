
import java.awt.Color;
import java.awt.Cursor;
import java.io.File;
import java.io.IOException;

import javax.swing.JTextArea;
import javax.swing.event.*;
import javax.swing.event.CaretListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.Utilities;


public class Controller {
	static int linenum = 1;
	
	
	public static void loadFile(File ldfile, int num){//紐⑤뜽�쓽 load �샇異�
		Model.load(ldfile, num);
	}
	
	public static void saveFile(File svfile, String content, int num) throws IOException{//紐⑤뜽�쓽 save�샇異�
		Model.save(svfile, content, num);
	}
	
	public static void saveStringToModel(int num){//Model의 file의 string을 Arraylist에 줄별로 저장 
		Model.saveString(num);
	}
	
	public static void copyToLeft(viewview left, viewview right) {		
		Model.left_String.set(linenum-1, Model.right_String.get(linenum-1));
		compareText(left,right);
	}
	
	public static void copyToRight(viewview left, viewview right) {
		Model.right_String.set(linenum-1, Model.left_String.get(linenum-1));
		compareText(left,right);
	}
	
	public static void AllcopyToLeft(viewview left, viewview right) {
		left.textPane.setText(right.textPane.getText());
	}
	
	public static void AllcopyToRight(viewview left, viewview right) {
		right.textPane.setText(left.textPane.getText());
	}
	
	public static void compareText(viewview left, viewview right) {
		
		int rightSize = Model.right_String.size() + 1;
		int leftSize = Model.left_String.size() + 1;
		int lcs[][] = new int[leftSize][rightSize];
		
		
		DefaultHighlighter Lhighlighter =  (DefaultHighlighter)left.textPane.getHighlighter();
		DefaultHighlighter Rhighlighter =  (DefaultHighlighter)right.textPane.getHighlighter();
		
		Highlighter.HighlightPainter paint = new DefaultHighlighter.DefaultHighlightPainter(Color.GREEN);
		
		// Boolean false濡� �쟾遺� 珥덇린�솕
		for(int i=0; i<rightSize; i++) 
			Model.right_Boolean.add(false);		
		for(int i=0; i<leftSize; i++)
			Model.left_Boolean.add(false);

		// 媛� �뒪�듃留곸뿉 0 異붽�(LCS �렪�븯寃� �븯湲� �쐞�빐�꽌)
		Model.left_String.add(0,"0");
		Model.right_String.add(0,"0");		
		
		//lcs �븣怨좊━利�
		for(int i=1; i<leftSize; i++) {
			
			for(int j=1; j<rightSize; j++) {
				
				if(i == 0 || j == 0) {
					lcs[i][j] = 0;
					continue;
				}
				
				if(Model.left_String.get(i).equals(Model.right_String.get(j))) {
					lcs[i][j] = lcs[i-1][j-1] + 1;
				}
				else {
					if(lcs[i-1][j] > lcs[i][j-1])
						lcs[i][j] = lcs[i-1][j];
					else
						lcs[i][j] = lcs[i][j-1];
				}	
			}
		}		
		

		// lcs �뿭異붿쟻�븯�뿬 媛숈� �뒪�듃留곸쓣 援ы븿
		int i = leftSize - 1;
		int j = rightSize - 1;		
		while(lcs[i][j] != 0) {
			
			if(lcs[i][j] == lcs[i][j-1]) {
				j--;
			}
			else if(lcs[i][j] == lcs[i-1][j]) {
				i--;
			}
			else if(lcs[i][j] - 1 == lcs[i-1][j-1]) {
				Model.left_Boolean.set(i, true);
				Model.right_Boolean.set(j, true);					
				i--;
				j--;
			}
		}		
		
		// 0 異붽��뻽�뜕嫄� �젣嫄�
		Model.right_String.remove(0);	Model.right_Boolean.remove(0);
		Model.left_String.remove(0);	Model.left_Boolean.remove(0);
							
		// TRUE FALSE 鍮꾧탳�빐�꽌 怨듬갚 異붽�
		for(int k=0; k<Model.right_String.size() && k<Model.left_String.size(); k++) {
			if(Model.left_Boolean.get(k).equals(false) && Model.right_Boolean.get(k).equals(true)) {
				Model.right_String.add(k,"   ");
				Model.right_Boolean.add(k,false);
			}
			else if(Model.left_Boolean.get(k).equals(true) && Model.right_Boolean.get(k).equals(false) ) {
				Model.left_String.add(k,"   ");
				Model.left_Boolean.add(k,false);
			}				
		}
		
		
		// 媛� textPane�뿉 �옱�엯�젰
		String x = "";
		String y = "";
		
		for(int k=0; k<Model.left_String.size(); k++) 
			x += Model.left_String.get(k) + "\n";
		
		for(int k=0; k<Model.right_String.size(); k++)
			y += Model.right_String.get(k) + "\n";
		
		left.textPane.setText(x);			
		right.textPane.setText(y);
		
		
		// ��由� 遺�遺� highlight
		
		
		
		int r=0;
		int l=0;
		
		Lhighlighter.setDrawsLayeredHighlights(false);
		Rhighlighter.setDrawsLayeredHighlights(false);
		 
		try {			
			int n=0;
			int m=0;
			
			for(l=0; l<Model.left_Boolean.size(); l++) {
				int leftStart=left.textPane.getLineStartOffset(n);
				int leftEnd = left.textPane.getLineEndOffset(n);
				
				if(Model.left_Boolean.get(l).equals(false)) {
					Lhighlighter.addHighlight(leftStart, leftEnd, paint);
				}				
					leftStart += Model.left_String.get(l).length() + 1;
					leftEnd = leftStart +  Model.left_String.get(l).length();
					n++;
					
 			}
			
			for(r=0; r<Model.right_Boolean.size(); r++) {
				
				int rightStart= right.textPane.getLineStartOffset(m);
				int rightEnd  = right.textPane.getLineEndOffset(m);
				
				if(Model.right_Boolean.get(r).equals(false)){
					Rhighlighter.addHighlight(rightStart, rightEnd, paint);
				}
					rightStart += Model.right_String.get(r).length() + 1;	
					rightEnd = rightStart +  Model.right_String.get(r).length();
					m++;
			}			
	
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		
		// 而ㅼ꽌媛� 紐뉖쾲吏� 以꾩뿉 �엳�뒗吏� 援ы븯湲�
		
		
		// Boolean 吏��슦湲�
		Model.left_Boolean.clear();
		Model.right_Boolean.clear();
	}	
	
	public static void setLineNum(int line){
	linenum=line;
	}
	public static void incereaselineNum(){
		linenum++;
		}
	

	
	
}
	
