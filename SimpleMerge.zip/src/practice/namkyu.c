#include <stdio.h>

int main() {
	printf("Hello Namkyu");
	return 0;

}