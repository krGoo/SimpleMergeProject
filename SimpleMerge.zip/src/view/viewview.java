package view;

import javax.swing.JPanel;

import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;

abstract class viewview extends JPanel{
	JButton savebtn ;
	JButton editbtn ;
	JButton loadbtn ;
	JScrollPane scrollPane ;
	JTextPane textPane ;

	public viewview() {
		initialize();
	}
	
	abstract public void initialize();
	
	abstract public void showloadedFile(int num);

}
