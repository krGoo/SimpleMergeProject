package view;

import java.awt.Color;
import java.awt.Cursor;
import java.io.File;
import java.io.IOException;

import javax.swing.JTextArea;
import javax.swing.event.*;
import javax.swing.event.CaretListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.Utilities;


public class Controller {
	static int left_linenum = 1;
	static int right_linenum = 1;
	
	public static void loadFile(File ldfile, int num){//���� load ȣ��
		Model.load(ldfile, num);
	}
	
	public static void saveFile(File svfile, String content, int num) throws IOException{//���� saveȣ��
		Model.save(svfile, content, num);
	}
	
	public static void saveStringToModel(int num){//���� saveString ȣ��
		Model.saveString(num);
	}
	
	public static void copyToLeft(viewview left, viewview right) {		
		Model.left_String.set(right_linenum-1, Model.right_String.get(right_linenum-1));
		compareText(left,right);
	}
	
	public static void copyToRight(viewview left, viewview right) {
		Model.right_String.set(left_linenum-1, Model.left_String.get(left_linenum-1));
		compareText(left,right);
	}
	
	public static void AllcopyToLeft(viewview left, viewview right) {
		left.textPane.setText(right.textPane.getText());
	}
	
	public static void AllcopyToRight(viewview left, viewview right) {
		right.textPane.setText(left.textPane.getText());
	}
	
	public static void compareText(viewview left, viewview right) {
		
		int rightSize = Model.right_String.size() + 1;
		int leftSize = Model.left_String.size() + 1;
		int lcs[][] = new int[leftSize][rightSize];
		Highlighter.HighlightPainter paint = new DefaultHighlighter.DefaultHighlightPainter(Color.GREEN);
		
		// Boolean false�� ���� �ʱ�ȭ
		for(int i=0; i<rightSize; i++) 
			Model.right_Boolean.add(false);		
		for(int i=0; i<leftSize; i++)
			Model.left_Boolean.add(false);

		// �� ��Ʈ���� 0 �߰�(LCS ���ϰ� �ϱ� ���ؼ�)
		Model.left_String.add(0,"0");
		Model.right_String.add(0,"0");		
		
		//lcs �˰�����
		for(int i=1; i<leftSize; i++) {
			
			for(int j=1; j<rightSize; j++) {
				
				if(i == 0 || j == 0) {
					lcs[i][j] = 0;
					continue;
				}
				
				if(Model.left_String.get(i).equals(Model.right_String.get(j))) {
					lcs[i][j] = lcs[i-1][j-1] + 1;
				}
				else {
					if(lcs[i-1][j] > lcs[i][j-1])
						lcs[i][j] = lcs[i-1][j];
					else
						lcs[i][j] = lcs[i][j-1];
				}	
			}
		}		
		

		// lcs �������Ͽ� ���� ��Ʈ���� ����
		int i = leftSize - 1;
		int j = rightSize - 1;		
		while(lcs[i][j] != 0) {
			
			if(lcs[i][j] == lcs[i][j-1]) {
				j--;
			}
			else if(lcs[i][j] == lcs[i-1][j]) {
				i--;
			}
			else if(lcs[i][j] - 1 == lcs[i-1][j-1]) {
				Model.left_Boolean.set(i, true);
				Model.right_Boolean.set(j, true);					
				i--;
				j--;
			}
		}		
		
		// 0 �߰��ߴ��� ����
		Model.right_String.remove(0);	Model.right_Boolean.remove(0);
		Model.left_String.remove(0);	Model.left_Boolean.remove(0);
							
		// TRUE FALSE ���ؼ� ���� �߰�
		for(int k=0; k<Model.right_String.size() && k<Model.left_String.size(); k++) {
			if(Model.left_Boolean.get(k).equals(false) && Model.right_Boolean.get(k).equals(true)) {
				Model.right_String.add(k,"   ");
				Model.right_Boolean.add(k,false);
			}
			else if(Model.left_Boolean.get(k).equals(true) && Model.right_Boolean.get(k).equals(false) ) {
				Model.left_String.add(k,"   ");
				Model.left_Boolean.add(k,false);
			}				
		}
		
		
		// �� textPane�� ���Է�
		String x = "";
		String y = "";
		
		for(int k=0; k<Model.left_String.size(); k++) 
			x += Model.left_String.get(k) + "\n";
		
		for(int k=0; k<Model.right_String.size(); k++)
			y += Model.right_String.get(k) + "\n";
		
		left.textPane.setText(x);			
		right.textPane.setText(y);
		
		
		// Ʋ�� �κ� highlight
		int rightStart=0;
		int leftStart=0;
		int r=0;
		int l=0;
		try {			
			for(l=0; l<Model.left_Boolean.size(); l++) {
				if(Model.left_Boolean.get(l).equals(false))
					left.textPane.getHighlighter().addHighlight(leftStart, leftStart +  Model.left_String.get(l).length(), paint);
				leftStart += Model.left_String.get(l).length() + 1;	
			}
			
			for(r=0; r<Model.right_Boolean.size(); r++) {
				if(Model.right_Boolean.get(r).equals(false))
					right.textPane.getHighlighter().addHighlight(rightStart, rightStart +  Model.right_String.get(r).length(), paint);	
				rightStart += Model.right_String.get(r).length() + 1;				
			}			
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		
		// Ŀ���� ���° �ٿ� �ִ��� ���ϱ�
		getLineNum(left, right);
		
		// Boolean �����
		Model.left_Boolean.clear();
		Model.right_Boolean.clear();
	}	
	
	public static void getLineNum(viewview left, viewview right) {		
		left.textPane.addCaretListener(new CaretListener() {               
            public void caretUpdate(CaretEvent e) {
                JTextArea editArea = (JTextArea)e.getSource();
                try {
                    int caretpos = editArea.getCaretPosition();
                    left_linenum = editArea.getLineOfOffset(caretpos);

                    left_linenum += 1;
                }
                catch(Exception ex) { }               
            }            
        });
		
		right.textPane.addCaretListener(new CaretListener() {               
            public void caretUpdate(CaretEvent e) {
                JTextArea editArea = (JTextArea)e.getSource();
                try {
                    int caretpos = editArea.getCaretPosition();
                    right_linenum = editArea.getLineOfOffset(caretpos);

                    right_linenum += 1;
                }
                catch(Exception ex) { }               
            }            
        });
	}
	
}
	
