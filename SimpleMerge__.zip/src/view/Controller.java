package view;

import java.awt.Color;
import java.awt.Cursor;
import java.io.File;
import java.io.IOException;

import javax.swing.JTextArea;
import javax.swing.event.*;
import javax.swing.event.CaretListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.Utilities;


public class Controller {
	static int left_linenum = 1;
	static int right_linenum = 1;
	
	public static void loadFile(File ldfile, int num){//모델의 load 호출
		Model.load(ldfile, num);
	}
	
	public static void saveFile(File svfile, String content, int num) throws IOException{//모델의 save호출
		Model.save(svfile, content, num);
	}
	
	public static void saveStringToModel(int num){//모델의 saveString 호출
		Model.saveString(num);
	}
	
	public static void copyToLeft(viewview left, viewview right) {		
		Model.left_String.set(right_linenum-1, Model.right_String.get(right_linenum-1));
		compareText(left,right);
	}
	
	public static void copyToRight(viewview left, viewview right) {
		Model.right_String.set(left_linenum-1, Model.left_String.get(left_linenum-1));
		compareText(left,right);
	}
	
	public static void AllcopyToLeft(viewview left, viewview right) {
		left.textPane.setText(right.textPane.getText());
	}
	
	public static void AllcopyToRight(viewview left, viewview right) {
		right.textPane.setText(left.textPane.getText());
	}
	
	public static void compareText(viewview left, viewview right) {
		
		int rightSize = Model.right_String.size() + 1;
		int leftSize = Model.left_String.size() + 1;
		int lcs[][] = new int[leftSize][rightSize];
		
		
		DefaultHighlighter Lhighlighter =  (DefaultHighlighter)left.textPane.getHighlighter();
		DefaultHighlighter Rhighlighter =  (DefaultHighlighter)right.textPane.getHighlighter();
		
		Highlighter.HighlightPainter paint = new DefaultHighlighter.DefaultHighlightPainter(Color.GREEN);
		
		// Boolean false로 전부 초기화
		for(int i=0; i<rightSize; i++) 
			Model.right_Boolean.add(false);		
		for(int i=0; i<leftSize; i++)
			Model.left_Boolean.add(false);

		// 각 스트링에 0 추가(LCS 편하게 하기 위해서)
		Model.left_String.add(0,"0");
		Model.right_String.add(0,"0");		
		
		//lcs 알고리즘
		for(int i=1; i<leftSize; i++) {
			
			for(int j=1; j<rightSize; j++) {
				
				if(i == 0 || j == 0) {
					lcs[i][j] = 0;
					continue;
				}
				
				if(Model.left_String.get(i).equals(Model.right_String.get(j))) {
					lcs[i][j] = lcs[i-1][j-1] + 1;
				}
				else {
					if(lcs[i-1][j] > lcs[i][j-1])
						lcs[i][j] = lcs[i-1][j];
					else
						lcs[i][j] = lcs[i][j-1];
				}	
			}
		}		
		

		// lcs 역추적하여 같은 스트링을 구함
		int i = leftSize - 1;
		int j = rightSize - 1;		
		while(lcs[i][j] != 0) {
			
			if(lcs[i][j] == lcs[i][j-1]) {
				j--;
			}
			else if(lcs[i][j] == lcs[i-1][j]) {
				i--;
			}
			else if(lcs[i][j] - 1 == lcs[i-1][j-1]) {
				Model.left_Boolean.set(i, true);
				Model.right_Boolean.set(j, true);					
				i--;
				j--;
			}
		}		
		
		// 0 추가했던거 제거
		Model.right_String.remove(0);	Model.right_Boolean.remove(0);
		Model.left_String.remove(0);	Model.left_Boolean.remove(0);
							
		// TRUE FALSE 비교해서 공백 추가
		for(int k=0; k<Model.right_String.size() && k<Model.left_String.size(); k++) {
			if(Model.left_Boolean.get(k).equals(false) && Model.right_Boolean.get(k).equals(true)) {
				Model.right_String.add(k,"   ");
				Model.right_Boolean.add(k,false);
			}
			else if(Model.left_Boolean.get(k).equals(true) && Model.right_Boolean.get(k).equals(false) ) {
				Model.left_String.add(k,"   ");
				Model.left_Boolean.add(k,false);
			}				
		}
		
		
		// 각 textPane에 재입력
		String x = "";
		String y = "";
		
		for(int k=0; k<Model.left_String.size(); k++) 
			x += Model.left_String.get(k) + "\n";
		
		for(int k=0; k<Model.right_String.size(); k++)
			y += Model.right_String.get(k) + "\n";
		
		left.textPane.setText(x);			
		right.textPane.setText(y);
		
		
		// 틀린 부분 highlight
		
		
		
		int r=0;
		int l=0;
		
		Lhighlighter.setDrawsLayeredHighlights(false);
		Rhighlighter.setDrawsLayeredHighlights(false);
		 
		try {			
			int n=0;
			int m=0;
			
			for(l=0; l<Model.left_Boolean.size(); l++) {
				int leftStart=left.textPane.getLineStartOffset(n);
				int leftEnd = left.textPane.getLineEndOffset(n);
				
				if(Model.left_Boolean.get(l).equals(false)) {
					Lhighlighter.addHighlight(leftStart, leftEnd, paint);
				}				
					leftStart += Model.left_String.get(l).length() + 1;
					leftEnd = leftStart +  Model.left_String.get(l).length();
					n++;
					
 			}
			
			for(r=0; r<Model.right_Boolean.size(); r++) {
				
				int rightStart= right.textPane.getLineStartOffset(m);
				int rightEnd  = right.textPane.getLineEndOffset(m);
				
				if(Model.right_Boolean.get(r).equals(false)){
					Rhighlighter.addHighlight(rightStart, rightEnd, paint);
				}
					rightStart += Model.right_String.get(r).length() + 1;	
					rightEnd = rightStart +  Model.right_String.get(r).length();
					m++;
			}			
	
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		
		// 커서가 몇번째 줄에 있는지 구하기
		getLineNum(left, right);
		
		// Boolean 지우기
		Model.left_Boolean.clear();
		Model.right_Boolean.clear();
	}	
	
	public static void getLineNum(viewview left, viewview right) {		
		left.textPane.addCaretListener(new CaretListener() {               
            public void caretUpdate(CaretEvent e) {
                JTextArea editArea = (JTextArea)e.getSource();
                try {
                    int caretpos = editArea.getCaretPosition();
                    left_linenum = editArea.getLineOfOffset(caretpos);

                    left_linenum += 1;
                }
                catch(Exception ex) { }               
            }            
        });
		
		right.textPane.addCaretListener(new CaretListener() {               
            public void caretUpdate(CaretEvent e) {
                JTextArea editArea = (JTextArea)e.getSource();
                try {
                    int caretpos = editArea.getCaretPosition();
                    right_linenum = editArea.getLineOfOffset(caretpos);

                    right_linenum += 1;
                }
                catch(Exception ex) { }               
            }            
        });
	}
	
}
	
